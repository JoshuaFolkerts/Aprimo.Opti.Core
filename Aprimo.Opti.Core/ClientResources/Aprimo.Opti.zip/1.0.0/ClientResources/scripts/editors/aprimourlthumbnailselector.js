﻿define([
    "dojo/_base/declare",
    "aprimointegration/editors/aprimoassetselector",
    "epi-cms/widget/_UrlSelectorMixin"
], function (declare, ThumbnailSelector, _UrlSelectorMixin) {
    return declare([ThumbnailSelector, _UrlSelectorMixin], {
    });
});